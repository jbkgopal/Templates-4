Thanks for downloading this theme! 

Theme Name: Vlava
Theme URL: https://themewagon.com/themes/free-html5-one-page-agency-website-template-valva
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com
