Thanks for downloading this template!

Template Name: MaxiBiz
Template URL: https://templatemag.com/maxibiz-bootstrap-business-template/
Author: TemplateMag.com
License: https://templatemag.com/license/
