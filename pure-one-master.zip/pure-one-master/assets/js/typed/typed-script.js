
	$(function () {
		$("#text-rotator").typed({
			strings: ["urity.", "ride.", "ower."],
			typeSpeed: 100,
			loop: true,
			startDelay: 100
		});
	});